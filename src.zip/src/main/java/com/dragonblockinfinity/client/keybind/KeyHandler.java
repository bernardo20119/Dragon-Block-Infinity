package com.dragonblockinfinity.client.keybind;

import com.dragonblockinfinity.DragonBlockInfinity;
import com.dragonblockinfinity.client.gui.screen.customization.CustomizationMenuScreen;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DragonBlockInfinity.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class KeyHandler {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        // Verifica se o tick terminou e se o player não está nulo (dentro do mundo)
        if (event.phase == TickEvent.Phase.END && Minecraft.getInstance().player != null) {
            while (KeyBindings.MENU_KEY.consumeClick()) {
                // Abre o menu na tela do jogador
                Minecraft.getInstance().setScreen(new CustomizationMenuScreen());
            }
        }
    }
}
