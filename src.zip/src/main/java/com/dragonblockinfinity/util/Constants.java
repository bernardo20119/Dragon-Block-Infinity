package com.dragonblockinfinity.util;

public class Constants {
    public static final String MOD_ID = "dragonblockinfinity";
    public static final String MOD_NAME = "Dragon Block Infinity";
    public static final String MOD_VERSION = "1.0.0";
}
